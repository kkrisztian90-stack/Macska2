# Mosolygós macska (Android)

Egy WebView-s app: a `app/src/main/assets/macska.html` oldalt jeleníti meg.
Koppintásra a macska mosolyog és nyávog, a számláló pedig számolja a koppintásokat.

## APK letöltése
GitHubon: Actions fül → legutóbbi "Build APK" futás → Artifacts → `macska-apk`.
Az `app-debug.apk`-t telefonra másolva telepíthető (engedélyezni kell az ismeretlen forrásból való telepítést).
